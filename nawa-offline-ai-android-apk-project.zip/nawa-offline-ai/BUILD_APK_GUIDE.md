# نواة الذكاء — دليل تحويل المشروع إلى ملف APK

هذا المشروع جاهز للتحويل مباشرة إلى ملف تثبيت أندرويد (`.apk`) ويعمل بالكامل **بدون إنترنت** (تم حذف صلاحية `INTERNET` عمداً من `AndroidManifest.xml`).

---

## الطريقة 1: عبر Android Studio (الأسهل محلياً)
1. فك ضغط ملف الـ ZIP في مجلد على جهازك.
2. افتح برنامج **Android Studio** واختر **Open** ثم حدد المجلد.
3. انتظر اكتمال مزامنة Gradle.
4. من القائمة العلوية اختر:
   **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. ستجد ملف الـ APK جاهزاً في:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## الطريقة 2: عبر سطر الأوامر (Gradle 8.7 + JDK 17)
```bash
gradle assembleDebug
```
أو لبناء نسخة Release:
```bash
gradle assembleRelease
```

---

## الطريقة 3: بناء APK تلقائياً على GitHub (بدون تثبيت Android Studio)
1. أنشئ مستودعاً جديداً على GitHub وارفع ملفات هذا المشروع إليه.
2. انتقل إلى تبويب **Actions** في GitHub واضغط **Run workflow** على `Build Offline AI APK`.
3. بعد ~3 دقائق، حمّل ملف `nawa-offline-ai-debug-apk` الجاهز للتثبيت مباشرة على هاتفك!

---

## كيف يعمل الذكاء الاصطناعي داخل التطبيق؟
- **النواة المدمجة (`OfflineBrainCore.kt` + `OfflineBuilderEngine.kt`)**: تفهم العربية والدارجة والإنجليزية، تحسب العمليات، تحفظ الحقائق في قاعدة بيانات SQLite داخل الهاتف، وتبني تطبيقات وأكواد فوراً.
- **قاعدة المعرفة (`assets/brain_knowledge.json`)**: مدمجة داخل الـ APK.
- **نموذج GGUF المحلي (`LocalLlmEngine.kt` + C++ JNI)**: لإضافة نموذج لغة ضخم (Qwen2.5-0.5B-Instruct)، ضع ملف `qwen2.5-0.5b-instruct-q4_k_m.gguf` داخل `app/src/main/assets/models/` قبل بناء الـ APK.
