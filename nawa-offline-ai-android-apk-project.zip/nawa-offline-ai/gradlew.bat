@echo off
where gradle >nul 2>nul
if %ERRORLEVEL%==0 (
  gradle %*
) else (
  echo Open this folder in Android Studio or install Gradle 8.7 to run assembleDebug.
  exit /b 1
)
