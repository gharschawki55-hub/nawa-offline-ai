Offline Model Bundle Folder
===========================
Target Model Profile: Qwen2.5-0.5B-Instruct (Q4_K_M (GGUF))
Expected Filename:    qwen2.5-0.5b-instruct-q4_k_m.gguf
Approx Weight Size:   ~398 MB

How to embed the LLM weights directly inside the APK:
1. Download qwen2.5-0.5b-instruct-q4_k_m.gguf (GGUF Q4_K_M quantization) on your computer.
2. Place it inside this directory: app/src/main/assets/models/qwen2.5-0.5b-instruct-q4_k_m.gguf
3. app/build.gradle.kts already sets noCompress += "gguf" so Android reads it directly.
4. Even without placing the large .gguf file, the built-in Kotlin Neural-Symbolic Brain
   (OfflineBrainCore.kt + OfflineBuilderEngine.kt + SQLite Memory) works immediately!
