cmake_minimum_required(VERSION 3.22.1)
project("offline_ai_jni")

# To enable full llama.cpp inference inside the APK:
# 1. Clone https://github.com/ggerganov/llama.cpp into app/src/main/cpp/llama.cpp
# 2. Uncomment the add_subdirectory and target_link_libraries lines below:
# add_subdirectory(llama.cpp)

add_library(offline_ai_jni SHARED native-lib.cpp)

find_library(log-lib log)

target_link_libraries(
    offline_ai_jni
    ${log-lib}
    # llama
)
