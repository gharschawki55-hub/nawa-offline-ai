#include <jni.h>
#include <string>
#include <fstream>
#include <android/log.h>

#define LOG_TAG "OfflineAiJni"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static std::string g_loaded_model_path;
static bool g_model_ready = false;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_nawa_offlineai_ai_LocalLlmEngine_nativeInitModel(
        JNIEnv* env,
        jobject /* this */,
        jstring modelPath) {
    const char* pathStr = env->GetStringUTFChars(modelPath, nullptr);
    std::ifstream file(pathStr, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        LOGI("Model file not found at: %s", pathStr);
        env->ReleaseStringUTFChars(modelPath, pathStr);
        g_model_ready = false;
        return JNI_FALSE;
    }
    auto sizeBytes = file.tellg();
    LOGI("Detected local GGUF model (%lld bytes) at %s", static_cast<long long>(sizeBytes), pathStr);
    g_loaded_model_path = pathStr;
    g_model_ready = sizeBytes > 1024;
    env->ReleaseStringUTFChars(modelPath, pathStr);
    return g_model_ready ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_nawa_offlineai_ai_LocalLlmEngine_nativeGenerate(
        JNIEnv* env,
        jobject /* this */,
        jstring prompt) {
    const char* promptStr = env->GetStringUTFChars(prompt, nullptr);
    std::string response;
    if (g_model_ready) {
        // When llama.cpp submodule is linked, replace this block with llama_decode() token loop.
        response = std::string("[GGUF Ready: ") + g_loaded_model_path + "] Prompt received: " + promptStr;
    } else {
        response = "";
    }
    env->ReleaseStringUTFChars(prompt, promptStr);
    return env->NewStringUTF(response.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_nawa_offlineai_ai_LocalLlmEngine_nativeFreeModel(
        JNIEnv* /* env */,
        jobject /* this */) {
    g_model_ready = false;
    g_loaded_model_path.clear();
}
