package com.nawa.offlineai

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.nawa.offlineai.ai.BuiltArtifact
import com.nawa.offlineai.ai.LocalLlmEngine
import com.nawa.offlineai.ai.OfflineBrainCore
import com.nawa.offlineai.data.LocalMemoryStore
import kotlinx.coroutines.launch

data class UiChatMessage(
    val isUser: Boolean,
    val text: String,
    val intentLabel: String? = null,
    val artifact: BuiltArtifact? = null
)

class MainActivity : ComponentActivity() {
    private lateinit var memoryStore: LocalMemoryStore
    private lateinit var llmEngine: LocalLlmEngine
    private lateinit var brainCore: OfflineBrainCore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        memoryStore = LocalMemoryStore(this)
        llmEngine = LocalLlmEngine(this)
        brainCore = OfflineBrainCore(this, memoryStore, llmEngine)

        setContent {
            val accent = Color(0xFF0F766E)
            MaterialTheme(
                colorScheme = lightColorScheme(primary = accent)
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    OfflineAiScreen(brainCore, llmEngine)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        llmEngine.release()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfflineAiScreen(brainCore: OfflineBrainCore, llmEngine: LocalLlmEngine) {
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var previewArtifact by remember { mutableStateOf<BuiltArtifact?>(null) }
    val messages = remember {
        mutableStateListOf(
            UiChatMessage(
                isUser = false,
                text = "مرحباً! أنا ذكاء اصطناعي أعمل بالكامل داخل تطبيقك بدون إنترنت. اسألني، أو اطلب مني بناء أداة، أو حفظ معلومة."
            )
        )
    }

    LaunchedEffect(Unit) {
        llmEngine.initializeFromAssets()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("نواة الذكاء — بدون إنترنت") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp)
        ) {
            previewArtifact?.let { art ->
                if (art.isWebPreviewable) {
                    Card(modifier = Modifier.fillMaxWidth().height(260.dp).padding(bottom = 8.dp)) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(art.title, style = MaterialTheme.typography.titleSmall)
                                TextButton(onClick = { previewArtifact = null }) { Text("إغلاق") }
                            }
                            HtmlArtifactWebView(html = art.code)
                        }
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { msg ->
                    Surface(
                        color = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            msg.intentLabel?.let {
                                Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                            Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                            msg.artifact?.let { art ->
                                Spacer(Modifier.height(6.dp))
                                if (art.isWebPreviewable) {
                                    Button(onClick = { previewArtifact = art }) {
                                        Text("تشغيل المعاينة الحية")
                                    }
                                } else {
                                    Text(art.code, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text("اكتب سؤالك أو ما تريد بناءه...") },
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty()) {
                            messages.add(UiChatMessage(isUser = true, text = prompt))
                            input = ""
                            scope.launch {
                                val reply = brainCore.process(prompt)
                                messages.add(
                                    UiChatMessage(
                                        isUser = false,
                                        text = reply.text,
                                        intentLabel = reply.intentLabel,
                                        artifact = reply.artifact
                                    )
                                )
                            }
                        }
                    }
                ) {
                    Text("إرسال")
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlArtifactWebView(html: String) {
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                // Block any accidental network access inside generated mini-apps
                settings.allowFileAccess = false
                loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        },
        update = { webView ->
            webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        },
        modifier = Modifier.fillMaxSize()
    )
}
