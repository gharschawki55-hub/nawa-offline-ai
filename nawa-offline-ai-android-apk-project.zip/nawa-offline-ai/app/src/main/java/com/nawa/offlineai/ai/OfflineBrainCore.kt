package com.nawa.offlineai.ai

import android.content.Context
import com.nawa.offlineai.data.LocalMemoryStore
import org.json.JSONObject
import kotlin.math.sqrt

data class BrainReply(
    val text: String,
    val intentLabel: String,
    val artifact: BuiltArtifact? = null
)

class OfflineBrainCore(
    private val context: Context,
    private val memoryStore: LocalMemoryStore,
    private val llmEngine: LocalLlmEngine
) {
    private data class KbItem(val topic: String, val keywords: List<String>, val answerAr: String)

    private val knowledgeItems: List<KbItem> by lazy { loadKnowledgeFromAssets() }

    private fun loadKnowledgeFromAssets(): List<KbItem> {
        return try {
            val raw = context.assets.open("brain_knowledge.json").bufferedReader().use { it.readText() }
            val root = JSONObject(raw)
            val arr = root.getJSONArray("entries")
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val kwArr = obj.getJSONArray("keywords")
                    val kws = (0 until kwArr.length()).map { kwArr.getString(it) }
                    add(KbItem(obj.getString("topicAr"), kws, obj.getString("answerAr")))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun normalize(text: String): String {
        val arabicDigits = "٠١٢٣٤٥٦٧٨٩"
        val sb = StringBuilder()
        for (ch in text.lowercase().trim()) {
            val digitIdx = arabicDigits.indexOf(ch)
            when {
                digitIdx >= 0 -> sb.append(digitIdx)
                ch in listOf('أ', 'إ', 'آ') -> sb.append('ا')
                ch == 'ة' -> sb.append('ه')
                ch == 'ى' -> sb.append('ي')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    suspend fun process(rawInput: String): BrainReply {
        val input = rawInput.trim()
        val norm = normalize(input)

        // 1. Save to Local SQLite Memory
        val saveRegex = Regex("(?:تذكر ان|احفظ ان|remember that)\s+(.+?)\s+(?:هو|هي|is|=|:)\s+(.+)")
        saveRegex.find(norm)?.let { match ->
            val key = match.groupValues[1].trim()
            val value = match.groupValues[2].trim()
            memoryStore.saveFact(key, value)
            return BrainReply(
                text = "تم الحفظ في الذاكرة المحلية (SQLite):\n• $key: $value",
                intentLabel = "حفظ بالذاكرة"
            )
        }

        // 2. Recall Memory
        if (Regex("ماذا تتذكر|ذاكرتي|فكرني|وش حفظت|my notes").containsMatchIn(norm)) {
            val facts = memoryStore.getAllFacts()
            if (facts.isEmpty()) {
                return BrainReply("الذاكرة المحلية فارغة حالياً.", "الذاكرة المحلية")
            }
            val formatted = facts.joinToString("\n") { "• ${it.key}: ${it.value}" }
            return BrainReply("المعلومات المحفوظة على جهازك:\n$formatted", "استرجاع الذاكرة")
        }

        // 3. Safe Arithmetic Evaluation
        evalMath(norm)?.let { result ->
            return BrainReply("النتيجة المحسوبة محلياً: $result", "معالجة حسابية")
        }

        // 4. Local Builder Engine
        if (Regex("ابني|اصنع|صمم|انشئ|اكتب كود|build|create").containsMatchIn(norm)) {
            val artifact = OfflineBuilderEngine.buildFromPrompt(norm, input)
            return BrainReply(
                text = "تم بناء (${artifact.title}) محلياً بدون إنترنت. يمكنك معاينته أو نسخه الآن.",
                intentLabel = "بناء محلي",
                artifact = artifact
            )
        }

        // 5. Local Knowledge Retrieval
        val queryTokens = norm.split(Regex("[^a-z0-9\u0600-\u06FF]+")).filter { it.length >= 2 }
        var bestScore = 0.0
        var bestItem: KbItem? = null
        for (item in knowledgeItems) {
            val docTokens = normalize(item.topic + " " + item.keywords.joinToString(" ")).split(" ").toSet()
            val hits = queryTokens.count { qt -> docTokens.any { it.contains(qt) || qt.contains(it) } }
            val score = if (queryTokens.isEmpty()) 0.0 else hits.toDouble() / sqrt((queryTokens.size * docTokens.size).toDouble().coerceAtLeast(1.0))
            if (score > bestScore) {
                bestScore = score
                bestItem = item
            }
        }
        if (bestItem != null && bestScore >= 0.22) {
            return BrainReply(bestItem.answerAr, "استرجاع معرفي")
        }

        // 6. Optional Native GGUF Inference (when model weights are bundled in assets/models/)
        llmEngine.generateWithLlm(input)?.let { generated ->
            return BrainReply(generated, "نموذج GGUF محلي")
        }

        return BrainReply(
            text = "تم استلام طلبك محلياً داخل ${llmEngine.activeModelName}. جرّب: 'ابنيلي آلة حاسبة' أو 'احسب (45 * 8)' أو 'تذكر أن اسمي أحمد'.",
            intentLabel = "معالجة محلية"
        )
    }

    private fun evalMath(norm: String): Double? {
        val match = Regex("[\d().+\-*/\s]{3,}").find(norm) ?: return null
        val expr = match.value.replace(" ", "")
        if (!expr.any { it.isDigit() } || !expr.any { it in listOf('+', '-', '*', '/') }) return null
        var pos = 0
        fun parseExpr(): Double {
            fun parseFactor(): Double {
                if (pos < expr.length && expr[pos] == '(') {
                    pos++
                    val v = parseExpr()
                    if (pos < expr.length && expr[pos] == ')') pos++
                    return v
                }
                val start = pos
                while (pos < expr.length && (expr[pos].isDigit() || expr[pos] == '.')) pos++
                return expr.substring(start, pos).toDouble()
            }
            fun parseTerm(): Double {
                var v = parseFactor()
                while (pos < expr.length && (expr[pos] == '*' || expr[pos] == '/')) {
                    val op = expr[pos++]
                    val r = parseFactor()
                    v = if (op == '*') v * r else v / r
                }
                return v
            }
            var v = parseTerm()
            while (pos < expr.length && (expr[pos] == '+' || expr[pos] == '-')) {
                val op = expr[pos++]
                val r = parseTerm()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        return try {
            val res = parseExpr()
            if (pos == expr.length && res.isFinite()) res else null
        } catch (_: Exception) {
            null
        }
    }
}
