package com.nawa.offlineai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class MemoryFact(
    val id: Long,
    val key: String,
    val value: String,
    val createdAt: Long
)

class LocalMemoryStore(context: Context) :
    SQLiteOpenHelper(context, "offline_ai_memory.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS memory_facts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fact_key TEXT NOT NULL,
                fact_value TEXT NOT NULL,
                created_at INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS memory_facts")
        onCreate(db)
    }

    fun saveFact(key: String, value: String): Long {
        val values = ContentValues().apply {
            put("fact_key", key.trim())
            put("fact_value", value.trim())
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insert("memory_facts", null, values)
    }

    fun getAllFacts(): List<MemoryFact> {
        val list = mutableListOf<MemoryFact>()
        val cursor = readableDatabase.rawQuery(
            "SELECT id, fact_key, fact_value, created_at FROM memory_facts ORDER BY id DESC",
            null
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    MemoryFact(
                        id = it.getLong(0),
                        key = it.getString(1),
                        value = it.getString(2),
                        createdAt = it.getLong(3)
                    )
                )
            }
        }
        return list
    }

    fun deleteFact(id: Long) {
        writableDatabase.delete("memory_facts", "id = ?", arrayOf(id.toString()))
    }
}
