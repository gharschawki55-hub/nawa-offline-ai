package com.nawa.offlineai.ai

data class BuiltArtifact(
    val title: String,
    val language: String,
    val code: String,
    val isWebPreviewable: Boolean
)

object OfflineBuilderEngine {

    fun buildFromPrompt(normalizedPrompt: String, rawPrompt: String): BuiltArtifact {
        return when {
            Regex("حاسبه|حساب|calculator|calc").containsMatchIn(normalizedPrompt) -> {
                BuiltArtifact(
                    title = "آلة حاسبة تفاعلية (أوفلاين)",
                    language = "html",
                    code = CALCULATOR_HTML,
                    isWebPreviewable = true
                )
            }
            Regex("مؤقت|بومودورو|ساعه|timer|pomodoro").containsMatchIn(normalizedPrompt) -> {
                BuiltArtifact(
                    title = "مؤقت بومودورو للتركيز",
                    language = "html",
                    code = POMODORO_HTML,
                    isWebPreviewable = true
                )
            }
            Regex("sql|قاعده بيانات|جدول|sqlite").containsMatchIn(normalizedPrompt) -> {
                BuiltArtifact(
                    title = "مخطط SQLite محلي",
                    language = "sql",
                    code = """
                        CREATE TABLE IF NOT EXISTS local_items (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            title TEXT NOT NULL,
                            content TEXT NOT NULL,
                            created_at INTEGER NOT NULL
                        );
                    """.trimIndent(),
                    isWebPreviewable = false
                )
            }
            else -> {
                BuiltArtifact(
                    title = "مكوّن Kotlin Jetpack Compose",
                    language = "kotlin",
                    code = """
                        @Composable
                        fun GeneratedOfflineCard() {
                            Surface(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                                Text("تم التوليد محلياً لطلب: ${rawPrompt.take(48)}")
                            }
                        }
                    """.trimIndent(),
                    isWebPreviewable = false
                )
            }
        }
    }

    private const val CALCULATOR_HTML = """<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:sans-serif;display:grid;place-items:center;min-height:100vh;margin:0;background:#f8fafc}.box{background:#fff;padding:16px;border-radius:16px;border:1px solid #e2e8f0;width:270px}#d{background:#0f172a;color:#fff;padding:12px;border-radius:8px;font-family:monospace;font-size:22px;margin-bottom:10px;text-align:left}.g{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}button{padding:12px;border:1px solid #e2e8f0;border-radius:8px;font-size:16px;font-weight:bold;background:#f8fafc}</style>
</head><body><div class="box"><div id="d">0</div><div class="g">
<button onclick="b=''">C</button><button onclick="a('/')">÷</button><button onclick="a('*')">×</button><button onclick="a('-')">-</button>
<button onclick="a('7')">7</button><button onclick="a('8')">8</button><button onclick="a('9')">9</button><button onclick="a('+')">+</button>
<button onclick="a('4')">4</button><button onclick="a('5')">5</button><button onclick="a('6')">6</button><button onclick="s()">=</button>
<button onclick="a('1')">1</button><button onclick="a('2')">2</button><button onclick="a('3')">3</button><button onclick="a('0')">0</button>
</div></div><script>var b='',d=document.getElementById('d');function a(c){b+=c;d.textContent=b}function s(){try{b=String(eval(b));d.textContent=b}catch(e){d.textContent='خطأ';b=''}}</script></body></html>"""

    private const val POMODORO_HTML = """<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:sans-serif;display:grid;place-items:center;min-height:100vh;margin:0;background:#f8fafc;text-align:center}.t{font-size:44px;font-family:monospace;font-weight:bold;margin:16px 0}button{padding:10px 18px;border-radius:10px;border:none;background:#0f766e;color:#fff;font-weight:bold}</style>
</head><body><div><h3>مؤقت التركيز</h3><div id="t" class="t">25:00</div><button onclick="go()">ابدأ / إيقاف</button></div>
<script>var sec=1500,id=null;function go(){if(id){clearInterval(id);id=null;return}id=setInterval(function(){if(sec>0){sec--;var m=String(Math.floor(sec/60)).padStart(2,'0'),s=String(sec%60).padStart(2,'0');document.getElementById('t').textContent=m+':'+s}},1000)}</script></body></html>"""
}
