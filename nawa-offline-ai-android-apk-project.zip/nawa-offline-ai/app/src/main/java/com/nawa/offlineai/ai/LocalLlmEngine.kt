package com.nawa.offlineai.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class LocalLlmEngine(private val context: Context) {

    var isNativeReady: Boolean = false
        private set

    var activeModelName: String = "Qwen2.5-0.5B-Instruct"
        private set

    init {
        try {
            System.loadLibrary("offline_ai_jni")
        } catch (_: UnsatisfiedLinkError) {
            isNativeReady = false
        }
    }

    private external fun nativeInitModel(modelPath: String): Boolean
    private external fun nativeGenerate(prompt: String): String
    private external fun nativeFreeModel()

    suspend fun initializeFromAssets(assetFileName: String = "models/qwen2.5-0.5b-instruct-q4_k_m.gguf"): Boolean =
        withContext(Dispatchers.IO) {
            val outFile = File(context.filesDir, "model.gguf")
            if (!outFile.exists()) {
                try {
                    context.assets.open(assetFileName).use { input ->
                        outFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                } catch (_: Exception) {
                    // No GGUF bundled yet; Built-in OfflineBrainCore handles everything seamlessly.
                    return@withContext false
                }
            }
            isNativeReady = try {
                nativeInitModel(outFile.absolutePath)
            } catch (_: UnsatisfiedLinkError) {
                false
            }
            isNativeReady
        }

    suspend fun generateWithLlm(prompt: String): String? = withContext(Dispatchers.Default) {
        if (!isNativeReady) return@withContext null
        try {
            val out = nativeGenerate(prompt)
            out.ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }

    fun release() {
        if (isNativeReady) {
            try { nativeFreeModel() } catch (_: Exception) {}
        }
    }
}
