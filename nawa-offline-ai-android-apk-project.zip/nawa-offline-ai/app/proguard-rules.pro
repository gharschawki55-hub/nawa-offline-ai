-keep class com.nawa.offlineai.ai.** { *; }
-keepclassmembers class com.nawa.offlineai.ai.LocalLlmEngine {
    native <methods>;
}
